(function(){
  var login = document.querySelector('input[value="Mit KIT-Account anmelden"]');
  login.click();
}())
